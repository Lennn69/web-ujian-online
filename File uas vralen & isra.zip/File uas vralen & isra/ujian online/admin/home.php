<?php
session_start();

if(empty($_SESSION['username']) or empty ($_SESSION['password'])){
   header('location: login.php');
}
?>

<style>
   /* Style Custom Dark Theme untuk Dashboard Home */
   .home-card {
      background: linear-gradient(135deg, rgba(30, 41, 59, 0.8) 0%, rgba(15, 23, 42, 0.9) 100%);
      border: 1px solid #334155;
      border-radius: 1.25rem;
      padding: 3rem 2rem;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
   }
   .welcome-icon {
      width: 70px;
      height: 70px;
      background: linear-gradient(135deg, #6366f1 0%, #06b6d4 100%);
      border-radius: 1.25rem;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1.5rem auto;
      box-shadow: 0 10px 20px -5px rgba(99, 102, 241, 0.4);
   }
</style>

<div class="jumbotron home-card text-center">
   <div class="container text-center">
      <div class="welcome-icon">
         <i class="fa-solid fa-hand-wave text-white text-3xl"></i>
      </div>
      <h2 style="margin-top: 0; font-weight: 700; color: #f8fafc;">
         Selamat Datang <b style="color: #38bdf8;"><?= $_SESSION['namalengkap']; ?></b>!
      </h2>
      <p style="color: #94a3b8; font-size: 1.1rem; margin-top: 0.75rem;">
         Anda login sebagai <span class="label label-primary" style="background-color: #4f46e5; padding: 0.4em 0.8em; font-size: 0.9rem; border-radius: 0.5rem; text-transform: uppercase; letter-spacing: 0.05em;"><?= $_SESSION['leveluser']; ?></span>
      </p>
   </div>
</div>