<?php
session_start();
ob_start();

//Mengatur batas login
$timeout = $_SESSION['timeout'];
if(time()<$timeout){
   $_SESSION['timeout'] = time()+5000;
}else{
   $_SESSION['login'] = 0;
}

//Mengecek status login
if(empty($_SESSION['username']) or empty($_SESSION['password']) or $_SESSION['login']==0){
   header('location: login.php');
}
?>

<html>
<head>
   
<title>Halaman Administrator</title>
 
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />

<link rel="stylesheet" type="text/css" href="../assets/bootstrap/css/bootstrap.min.css"/>
<link type="text/css" rel="stylesheet" href="../assets/dataTables/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../css/admin.css"/>

<!-- CDN FontAwesome untuk Icon Tambahan (Opsional) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   
<script type="text/javascript" src="../assets/jquery/jquery-2.0.2.min.js"></script>

<style>
   /* Style Custom Dark Theme Tanpa Mengubah Struktur HTML */
   body {
      background-color: #0b0f19;
      color: #e2e8f0;
      padding-top: 70px;
   }
   .navbar-default {
      background-color: #111827;
      border-color: #1f2937;
   }
   .navbar-default .navbar-nav > li > a {
      color: #9ca3af;
      font-weight: 500;
   }
   .navbar-default .navbar-nav > li > a:hover,
   .navbar-default .navbar-nav > li > a:focus {
      color: #38bdf8;
      background-color: #1f2937;
   }
   #content {
      background-color: #111827;
      border: 1px solid #1f2937;
      border-radius: 12px;
      padding: 24px;
      min-height: 500px;
      margin-top: 10px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
   }
   .jumbotron {
      background-color: #1f2937 !important;
      color: #f3f4f6 !important;
      border: 1px solid #374151;
      border-radius: 10px;
   }
   footer {
      margin-top: 40px;
      padding: 20px 0;
      border-top: 1px solid #1f2937;
      color: #6b7280;
      background-color: #0b0f19;
   }
</style>

</head>
<body>

<nav class="navbar navbar-default navbar-fixed-top"> 
   <div class="container">
      <?php include "menu.php"; ?> 
   </div>
</nav>   

<section>   
   <div class="container">
      <div class="row">
         <div class="col-xs-12" id="content"></div>
      </div>
   </div>
</section>

<footer> 
   <div class="container text-center">
      <p>@Copyright 2020 — <strong style="color: #38bdf8;">vralen & isra (ZyyLen)</strong></p>
   </div>
</footer>
   
<script type="text/javascript" src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/dataTables/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../assets/dataTables/js/dataTables.bootstrap.min.js"></script>

<script type="text/javascript" src="../js/admin.js"></script>

</body>
</html>