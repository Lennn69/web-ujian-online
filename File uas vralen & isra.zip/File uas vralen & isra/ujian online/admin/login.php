<html>
<head>
<title>Halaman Administrator</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />

<!-- Original CSS & Assets -->
<link rel="stylesheet" type="text/css" href="../assets/bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="../css/login.css"/>

<!-- Tailwind CSS & FontAwesome CDN untuk UI Modern -->
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
   body { 
      font-family: 'Plus Jakarta Sans', sans-serif; 
      background-color: #090d16;
   }
</style>
   
<script type="text/javascript" src="../assets/jquery/jquery-2.0.2.min.js"></script>
<script type="text/javascript">
$(function(){
   $('.alert').hide();
   $('.login-form').submit(function(){
      $('.alert').hide();
      if($('input[name=username]').val() == ""){
         $('.alert').fadeIn().html('Kotak input <b>Username</b> masih kosong!');
      }else if($('input[name=password]').val() == ""){
         $('.alert').fadeIn().html('Kotak input <b>Password</b> masih kosong!');
      }else{
         $.ajax({
            type : "POST",
            url : "login_cek.php",
            data : $(this).serialize(),
            success : function(data){
               if(data == "ok") window.location = "index.php"; 
               else $('.alert').fadeIn().html(data);  
            }
         });
      }
      return false;
   });
});
</script>
   
</head>
<body class="min-h-screen flex items-center justify-center p-4 sm:p-8 relative overflow-hidden">

   <!-- Ambient Glow Background Effects -->
   <div class="absolute -top-40 -left-40 w-[500px] h-[500px] bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none"></div>
   <div class="absolute -bottom-40 -right-40 w-[500px] h-[500px] bg-cyan-600/20 rounded-full blur-[120px] pointer-events-none"></div>

   <!-- Main Container Split Screen (Lebar Max 6XL) -->
   <div class="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 rounded-3xl bg-slate-900/80 backdrop-blur-xl border border-slate-800 shadow-2xl overflow-hidden relative z-10 min-h-[580px]">
      
      <!-- SISI KIRI: Watermark Large Branding Area -->
      <div class="lg:col-span-6 bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-950 p-8 sm:p-12 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800/80 relative overflow-hidden">
         
         <div class="relative z-10">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold tracking-wider uppercase mb-6">
               <i class="fa-solid fa-shield-halved text-xs"></i> Portal Administrator
            </div>
         </div>

         <!-- Watermark Teks Besar -->
         <div class="my-auto py-8 relative z-10">
            <p class="text-xs sm:text-sm font-bold tracking-[0.3em] uppercase text-indigo-400/80 mb-2">System Developed By</p>
            <h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-tight">
               vralen <span class="text-slate-500 font-light">&</span> isra
            </h1>
            <div class="mt-4 flex items-center gap-3">
               <span class="h-1 w-12 bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full"></span>
               <h2 class="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-cyan-400 to-teal-300">
                  ZyyLen
               </h2>
            </div>
            <p class="text-slate-400 text-sm mt-6 max-w-md leading-relaxed">
               Sistem Manajemen Ujian & Bank Soal Terintegrasi dengan Antarmuka Modern dan Performa Tinggi.
            </p>
         </div>

         <!-- Footer Kiri -->
         <div class="text-xs text-slate-500 font-medium relative z-10">
            &copy; CBT Exam System. All rights reserved.
         </div>

         <!-- Decorative Grid Pattern -->
         <div class="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none"></div>
      </div>

      <!-- SISI KANAN: Form Login Lebar -->
      <div class="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-center bg-slate-900/50">
         
         <!-- Alert Box Modern -->
         <div class="alert alert-danger mb-6 bg-rose-950/80 border border-rose-500/40 text-rose-300 rounded-xl p-4 text-xs font-semibold backdrop-blur-md shadow-lg shadow-rose-950/40" role="alert"> </div>
         
         <div class="mb-8">
            <h3 class="text-2xl sm:text-3xl font-extrabold text-slate-100 tracking-tight">Selamat Datang</h3>
            <p class="text-sm text-slate-400 mt-2">Silakan masukkan akun Anda untuk melanjutkan</p>
         </div>

         <!-- Form Login -->
         <form class="login-form space-y-6">
            
            <div>
               <label class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">Username</label>
               <div class="relative flex items-center">
                  <div class="absolute left-4 text-slate-400 pointer-events-none">
                     <i class="fa-solid fa-user text-base"></i>
                  </div>
                  <input type="text" name="username" placeholder="Masukkan Username..." autofocus class="w-full bg-slate-950/80 text-slate-100 placeholder-slate-500 text-sm rounded-xl pl-12 pr-4 py-4 border border-slate-700/80 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition duration-200 shadow-inner">
               </div>
            </div>
            
            <div>
               <label class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">Password</label>
               <div class="relative flex items-center">
                  <div class="absolute left-4 text-slate-400 pointer-events-none">
                     <i class="fa-solid fa-lock text-base"></i>
                  </div>
                  <input type="password" name="password" placeholder="Masukkan Password..." class="w-full bg-slate-950/80 text-slate-100 placeholder-slate-500 text-sm rounded-xl pl-12 pr-4 py-4 border border-slate-700/80 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition duration-200 shadow-inner">
               </div>
            </div>
            
            <button type="submit" class="w-full py-4 bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-sm sm:text-base rounded-xl shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/50 transition duration-200 flex items-center justify-center gap-3">
               <i class="fa-solid fa-right-to-bracket text-lg"></i> Login Administrator
            </button>

         </form>

      </div>

   </div>

</body>
</html>