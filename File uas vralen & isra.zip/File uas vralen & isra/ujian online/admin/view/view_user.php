<script type="text/javascript" src="script/script_user.js"> </script>

<style>
   /* Style Custom Dark Theme untuk Manajemen User */
   .modal-content {
      background-color: #111827 !important;
      border: 1px solid #1f2937 !important;
      border-radius: 12px !important;
      color: #f8fafc !important;
   }
   .modal-header, .modal-footer {
      border-color: #1f2937 !important;
   }
   .modal-title {
      color: #f8fafc !important;
      font-weight: 600;
   }
   .form-control {
      background-color: #1f2937 !important;
      border: 1px solid #374151 !important;
      color: #f8fafc !important;
      border-radius: 8px !important;
   }
   .form-control:focus {
      border-color: #38bdf8 !important;
      box-shadow: none !important;
   }
   .table {
      color: #e2e8f0 !important;
   }
   .table-striped > tbody > tr:nth-of-type(odd) {
      background-color: rgba(31, 41, 55, 0.5) !important;
   }
   .table-hover > tbody > tr:hover {
      background-color: rgba(51, 65, 85, 0.5) !important;
   }
   .table > thead > tr > th {
      border-bottom: 2px solid #374151 !important;
      color: #38bdf8 !important;
      text-transform: uppercase;
      font-size: 12px;
      letter-spacing: 0.05em;
   }
   .table > tbody > tr > td {
      border-top: 1px solid #1f2937 !important;
      vertical-align: middle !important;
   }
</style>

<?php
session_start();
if(empty($_SESSION['username']) or empty($_SESSION['password']) or $_SESSION['leveluser']!="admin"){
   header('location: ../login.php');
}

//Include library yang dibutuhkan
include "../../library/function_view.php";
include "../../library/function_form.php";

//Membuat judul dan tombol tambah user
create_title("user", "Manajemen User");
create_button("success", "plus-sign", "Tambah", "btn-add", "form_add()");

//Membuat header dan footer tabel
create_table(array("Nama", "Username", "Level", "Aksi"));


//Membuat form tambah dan edit user
open_form("modal_user", "return save_data()");
   create_textbox("Nama", "nama", "text", 4, "", "required");
   create_textbox("Username", "username", "text", 4, "", "required");
   create_textbox("Password", "password", "password", 4);
   
   $list = array();
   $list[] = array("guru", "Guru");
   $list[] = array("operator", "Operator");
   create_combobox("Level", "level", $list, 4, "", "required");

close_form();
?>