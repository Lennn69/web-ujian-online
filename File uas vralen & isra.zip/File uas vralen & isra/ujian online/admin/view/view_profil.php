<script type="text/javascript" src="script/script_profil.js"> </script>

<style>
   /* Custom Styling Dark Theme untuk Profil User */
   .form-horizontal .control-label {
      color: #9ca3af !important;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.05em;
   }
   .form-control {
      background-color: #1f2937 !important;
      border: 1px solid #374151 !important;
      color: #f8fafc !important;
      border-radius: 8px !important;
   }
   .form-control[readonly] {
      background-color: #111827 !important;
      border-color: #1f2937 !important;
      color: #9ca3af !important;
      cursor: not-allowed;
   }
   .form-control:focus {
      border-color: #38bdf8 !important;
      box-shadow: none !important;
   }
   hr {
      border-top: 1px solid #1f2937 !important;
      margin-top: 15px;
      margin-bottom: 25px;
   }
</style>

<?php
session_start();
if(empty($_SESSION['username']) or empty($_SESSION['password'])){
    header('location: ../login.php');
}

include "../../library/function_view.php";
include "../../library/function_form.php";

create_title("user", "Profil User");

echo '<hr/><form id="form-profil" class="form-horizontal" onsubmit="return edit_data()">';
    
create_textbox("Nama Lengkap", "nama_lengkap", "text", 4, "", 'value="'.$_SESSION['namalengkap'].'" readonly');
create_textbox("Username", "username", "text", 4, "", 'value="'.$_SESSION['username'].'" readonly');
create_textbox("Level", "level", "text", 4, "", 'value="'.$_SESSION['leveluser'].'" readonly');
create_textbox("Password Lama", "lama", "password", 4, "", "required");
create_textbox("Password Baru", "baru", "password", 4, "", "required");
create_textbox("Ulang Password", "ulang", "password", 4, "", "required");

echo '<div class="form-group">
<div class="col-md-2 col-md-offset-2"><button class="btn btn-primary"><i class="glyphicon glyphicon-refresh"></i> Ubah Password </button></div>
</div></form>';
?>