<script type="text/javascript" src="script/script_siswa.js"> </script>

<style>
   /* Style Custom Dark Theme untuk Manajemen Siswa */
   .modal-content {
      background-color: #111827 !important;
      border: 1px solid #1f2937 !important;
      border-radius: 12px !important;
      color: #f8fafc !important;
   }
   .modal-header, .modal-footer {
      border-color: #1f2937 !important;
   }
   .modal-title {
      color: #f8fafc !important;
      font-weight: 600;
   }
   .form-control {
      background-color: #1f2937 !important;
      border: 1px solid #374151 !important;
      color: #f8fafc !important;
      border-radius: 8px !important;
   }
   .form-control:focus {
      border-color: #38bdf8 !important;
      box-shadow: none !important;
   }
   .table {
      color: #e2e8f0 !important;
   }
   .table-striped > tbody > tr:nth-of-type(odd) {
      background-color: rgba(31, 41, 55, 0.5) !important;
   }
   .table-hover > tbody > tr:hover {
      background-color: rgba(51, 65, 85, 0.5) !important;
   }
   .table > thead > tr > th {
      border-bottom: 2px solid #374151 !important;
      color: #38bdf8 !important;
      text-transform: uppercase;
      font-size: 12px;
      letter-spacing: 0.05em;
   }
   .table > tbody > tr > td {
      border-top: 1px solid #1f2937 !important;
      vertical-align: middle !important;
   }
   /* Styling khusus tombol action/import file */
   input[type="file"] {
      color: #9ca3af !important;
   }
</style>

<?php
session_start();
if(empty($_SESSION['username']) or empty($_SESSION['password']) or $_SESSION['leveluser']!="admin"){
   header('location: ../login.php');
}

//Include library yang dibutuhkan
include "../../library/config.php";
include "../../library/function_view.php";
include "../../library/function_form.php";

//Membuat judul, tombol tambah, tombol import dan tombol cetak kartu
create_title("list-alt", "Manajemen Siswa");
create_button("success", "plus-sign", "Tambah", "btn-add", "form_add()");
create_button("primary", "import", "Import", "btn-import", "form_import()");
create_button("info", "print", "Cetak Kartu", "btn-print", "form_print()");

//Membuat header dan footer tabel
create_table(array("NIS", "Nama Siswa", "Password", "Kelas", "Aksi"));

//Membuat form tambah dan edit data
open_form("modal_siswa", "return save_data()");
   create_textbox("NIS", "nis", "text", 4, "", "required");
   create_textbox("Nama Siswa", "nama", "text", 6, "", "required");
   
   $qkelas = mysqli_query($mysqli, "SELECT * FROM kelas");
   $list = array();
   while($rk = mysqli_fetch_array($qkelas)){
      $list[] = array($rk['id_kelas'], $rk['kelas']);
   }
   create_combobox("Kelas", "kelas", $list, 4, "", "required");
close_form();

//Membuat form cetak kartu
open_form("modal_print", "return print_data()");
   $qkelas = mysqli_query($mysqli, "SELECT * FROM kelas");
   $list = array();
   while($rk = mysqli_fetch_array($qkelas)){
      $list[] = array($rk['id_kelas'], $rk['kelas']);
   }
   create_combobox("Kelas", "kelas_print", $list, 4, "", "required");
close_form("print", "Print");

//Membuat form import
open_form("modal_import", "return import_data()");
   create_textbox("Pilih File .xls", "file", "file", 6, "", "required");
   $qkelas = mysqli_query($mysqli, "SELECT * FROM kelas");
   $list = array();
   while($rk = mysqli_fetch_array($qkelas)){
      $list[] = array($rk['id_kelas'], $rk['kelas']);
   }
   create_combobox("Kelas", "kelas_import", $list, 4, "", "required");
close_form("import", "Import");
?>