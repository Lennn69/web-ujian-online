<link rel="stylesheet" type="text/css" href="../assets/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
<script type="text/javascript" src="../assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

<script type="text/javascript" src="script/script_ujian.js"> </script>

<style>
   /* Penyesuaian Tampilan Modul Ujian agar Serasi dengan Dark Theme */
   .modal-content {
      background-color: #111827 !important;
      border: 1px solid #1f2937 !important;
      border-radius: 12px !important;
      color: #f8fafc !important;
   }
   .modal-header, .modal-footer {
      border-color: #1f2937 !important;
   }
   .modal-title {
      color: #f8fafc !important;
      font-weight: 600;
   }
   .form-control {
      background-color: #1f2937 !important;
      border: 1px solid #374151 !important;
      color: #f8fafc !important;
      border-radius: 8px !important;
   }
   .form-control:focus {
      border-color: #38bdf8 !important;
      box-shadow: none !important;
   }
   .table {
      color: #e2e8f0 !important;
   }
   .table-striped > tbody > tr:nth-of-type(odd) {
      background-color: rgba(31, 41, 55, 0.5) !important;
   }
   .table-hover > tbody > tr:hover {
      background-color: rgba(51, 65, 85, 0.5) !important;
   }
   .table > thead > tr > th {
      border-bottom: 2px solid #374151 !important;
      color: #38bdf8 !important;
      text-transform: uppercase;
      font-size: 12px;
      letter-spacing: 0.05em;
   }
   .table > tbody > tr > td {
      border-top: 1px solid #1f2937 !important;
      vertical-align: middle !important;
   }
   /* Datepicker Custom Style */
   .datepicker {
      background-color: #1f2937 !important;
      color: #f8fafc !important;
      border: 1px solid #374151 !important;
   }
   .datepicker table tr td.day:hover {
      background-color: #38bdf8 !important;
      color: #0f172a !important;
   }
</style>

<?php
session_start();
if(empty($_SESSION['username']) or empty($_SESSION['password']) or $_SESSION['leveluser']!="admin"){
   header('location: ../login.php');
}

//include library yang diperlukan
include "../../library/config.php";
include "../../library/function_view.php";
include "../../library/function_form.php";

//membuat judul dan tombol tambah
create_title("edit", "Manajemen Ujian");
create_button("success", "plus-sign", "Tambah", "btn-add", "form_add()");

//membuat header dan footer tabel
create_table(array("Judul", "Nama Mapel", "Tanggal", "Waktu", "Jml. Soal", "Pengampu", "Aksi"));

//membuat form tambah dan edit data
open_form("modal_ujian", "return save_data()");
   create_textbox("Judul", "judul", "text", 4, "", "required");
   create_textbox("Nama Mapel", "mapel", "text", 4, "", "required");
   create_textbox("Tanggal", "tanggal", "text", 4, "datepicker", "required");
   create_textbox("Waktu (menit)", "waktu", "number", 2, "", "required");
   create_textbox("Jml. Soal", "jml_soal", "number", 2, "", "required");
   
   $quser = mysqli_query($mysqli, "SELECT * FROM user WHERE level='guru'");
   $list = array();
   while($ru = mysqli_fetch_array($quser)){
      $list[] = array($ru['id_user'], $ru['nama']);
   }
   create_combobox("Pengampu", "pengampu", $list, 4, "", "required");   
close_form();
?>