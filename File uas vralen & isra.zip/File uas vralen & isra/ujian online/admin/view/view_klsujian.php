<script type="text/javascript" src="script/script_klsujian.js"> </script>

<style>
   /* Style Custom Dark Theme untuk Manajemen Kelas Per Ujian */
   .modal-content {
      background-color: #111827 !important;
      border: 1px solid #1f2937 !important;
      border-radius: 12px !important;
      color: #f8fafc !important;
   }
   .modal-header, .modal-footer {
      border-color: #1f2937 !important;
   }
   .modal-title {
      color: #f8fafc !important;
      font-weight: 600;
   }
   .form-control {
      background-color: #1f2937 !important;
      border: 1px solid #374151 !important;
      color: #f8fafc !important;
      border-radius: 8px !important;
   }
   .form-control:focus {
      border-color: #38bdf8 !important;
      box-shadow: none !important;
   }
   .table {
      color: #e2e8f0 !important;
   }
   .table-striped > tbody > tr:nth-of-type(odd) {
      background-color: rgba(31, 41, 55, 0.5) !important;
   }
   .table-hover > tbody > tr:hover {
      background-color: rgba(51, 65, 85, 0.5) !important;
   }
   .table > thead > tr > th {
      border-bottom: 2px solid #374151 !important;
      color: #38bdf8 !important;
      text-transform: uppercase;
      font-size: 12px;
      letter-spacing: 0.05em;
   }
   .table > tbody > tr > td {
      border-top: 1px solid #1f2937 !important;
      vertical-align: middle !important;
   }
   /* Custom Styling Checkbox */
   .checkbox label {
      color: #cbd5e1 !important;
      font-weight: 500;
   }
   .checkbox input[type="checkbox"] {
      accent-color: #38bdf8;
   }
</style>

<?php
session_start();
if(empty($_SESSION['username']) or empty($_SESSION['password']) or $_SESSION['leveluser']!="admin"){
   header('location: ../login.php');
}

//Include library yang diperlukan
include "../../library/config.php";
include "../../library/function_view.php";
include "../../library/function_form.php";

//Membuat judul
create_title("sort-by-attributes", "Manajemen Kelas Per Ujian");

//Membuat header dan footer tabel
create_table(array("Judul Ujian", "Kelas", "Aksi"));

//Membuat form edit data
open_form("modal_klsujian", "return save_data()");
   $qkelas = mysqli_query($mysqli, "SELECT * FROM kelas");
   $list = array();
   while($rk = mysqli_fetch_array($qkelas)){
      $list[] = array($rk['id_kelas'], $rk['kelas']);
   }
   create_checkbox("Kelas", "kelas", $list); 
close_form();
?>