<?php
if (session_status() === PHP_SESSION_NONE) {
   session_start();
}

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
   header('Location: login.php');
   exit;
}

// Akun siswa memiliki session 'nis', sedangkan akun administrator
// tidak selalu memiliki session tersebut. Gunakan fallback agar
// halaman tidak menampilkan Undefined array key.
$identitas = $_SESSION['nis'] ?? $_SESSION['username'] ?? '';
$nama = $_SESSION['namalengkap'] ?? '';
$level = $_SESSION['leveluser'] ?? '';

if ($identitas === '' && $level !== '') {
   $identitas = ucfirst($level);
}
?>

<div class="navbar-header">
   <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
   </button>
</div>

<div id="navbar" class="navbar-collapse collapse">
   <ul class="nav navbar-nav">
      <li><a><i class="glyphicon glyphicon-user"></i> <?= htmlspecialchars($identitas, ENT_QUOTES, 'UTF-8') ?><?php if ($nama !== ''): ?>: <?= htmlspecialchars($nama, ENT_QUOTES, 'UTF-8') ?><?php endif; ?></a></li>
   </ul>
   <ul class="nav navbar-nav navbar-right">
      <li><a href="logout.php"><i class="glyphicon glyphicon-off"></i> Keluar </a></li>
   </ul>
</div>
